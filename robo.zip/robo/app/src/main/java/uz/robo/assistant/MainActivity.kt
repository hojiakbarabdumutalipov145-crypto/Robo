package uz.robo.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button
    private val langs = listOf("uz-UZ", "ru-RU", "en-US")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(col) })

        fun label(t: String, size: Float): TextView = TextView(this).apply {
            text = t
            textSize = size
            setPadding(0, pad / 2, 0, pad / 2)
            col.addView(this)
        }

        fun button(t: String, onClick: () -> Unit): Button = Button(this).apply {
            text = t
            isAllCaps = false
            setOnClickListener { onClick() }
            col.addView(this)
        }

        label("Robo", 30f)
        status = label(Status.last, 16f)

        button("1. Ruxsatlar berish") { askPermissions() }
        button("2. Boshqa ilovalar ustida ko'rsatish") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("3. Batareya cheklovini o'chirish") {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button("4. Telegramga o'zi yuborishi (Maxsus imkoniyatlar)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val key = EditText(this).apply {
            hint = "Gemini API kaliti (ixtiyoriy)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.geminiKey(this@MainActivity))
        }
        col.addView(key)
        button("Kalitni saqlash") {
            Prefs.setGeminiKey(this, key.text.toString())
            Toast.makeText(this, "Saqlandi", Toast.LENGTH_SHORT).show()
        }

        lateinit var langBtn: Button
        langBtn = button("Eshitish tili: ${Prefs.lang(this)}") {
            val next = langs[(langs.indexOf(Prefs.lang(this)) + 1) % langs.size]
            Prefs.setLang(this, next)
            langBtn.text = "Eshitish tili: $next"
            Toast.makeText(this, "Robo'ni to'xtatib qayta yoqing", Toast.LENGTH_SHORT).show()
        }

        toggle = button("") {
            if (RoboService.running) {
                startService(Intent(this, RoboService::class.java).setAction(RoboService.ACTION_STOP))
            } else {
                startForegroundService(Intent(this, RoboService::class.java))
            }
            toggle.postDelayed({ refreshToggle() }, 600)
        }
        toggle.textSize = 20f
        refreshToggle()
    }

    override fun onResume() {
        super.onResume()
        Status.listener = { s -> status.text = s; refreshToggle() }
        status.text = Status.last
        refreshToggle()
    }

    override fun onPause() {
        Status.listener = null
        super.onPause()
    }

    private fun refreshToggle() {
        toggle.text = if (RoboService.running) "Robo'ni to'xtatish" else "Robo'ni yoqish"
    }

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }
}
