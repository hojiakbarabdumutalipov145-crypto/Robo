package uz.robo.assistant

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Reminders {
    fun schedule(ctx: Context, text: String, delayMin: Int?, hhmm: String): String {
        if (text.isBlank()) return "Nimani eslatay?"
        val now = System.currentTimeMillis()
        val at: Long
        if (delayMin != null && delayMin > 0) {
            at = now + delayMin * 60_000L
        } else if (hhmm.matches(Regex("\\d{1,2}:\\d{2}"))) {
            val parts = hhmm.split(":")
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, parts[0].toInt())
            cal.set(Calendar.MINUTE, parts[1].toInt())
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
            at = cal.timeInMillis
        } else {
            return "Qachon eslatay?"
        }

        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, (at / 1000).toInt(),
            Intent(ctx, ReminderReceiver::class.java).putExtra("text", text),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
        return "Eslatma qo'yildi: " + SimpleDateFormat("HH:mm", Locale.US).format(Date(at))
    }
}

/** Eslatma vaqti kelganda bildirishnoma chiqaradi va ovoz bilan aytadi. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val text = intent.getStringExtra("text") ?: return

        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("robo_remind", "Eslatmalar", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.notify(
            text.hashCode(),
            Notification.Builder(ctx, "robo_remind")
                .setContentTitle("Robo eslatmasi")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setAutoCancel(true)
                .build()
        )

        val pending = goAsync()
        val app = ctx.applicationContext
        var tts: TextToSpeech? = null
        tts = TextToSpeech(app) { status ->
            Handler(Looper.getMainLooper()).post {
                val t = tts
                if (status != TextToSpeech.SUCCESS || t == null) {
                    pending.finish()
                    return@post
                }
                val options = listOf(Locale("uz", "UZ"), Locale("tr", "TR"), Locale("ru", "RU"), Locale.getDefault())
                for (l in options) {
                    if (t.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE) {
                        t.setLanguage(l)
                        break
                    }
                }
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) {
                        t.shutdown()
                        pending.finish()
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        t.shutdown()
                        pending.finish()
                    }
                })
                t.speak("Eslatma. $text", TextToSpeech.QUEUE_FLUSH, null, "remind")
            }
        }
    }
}
