package uz.robo.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper

/** Kirill/lotin matnini bitta ko'rinishga (kichik lotin harflar) keltiradi. */
object Text {
    private val cyr = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "yo",
        'ж' to "j", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m",
        'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u",
        'ф' to "f", 'х' to "x", 'ц' to "s", 'ч' to "ch", 'ш' to "sh", 'щ' to "sh", 'ъ' to "",
        'ы' to "i", 'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya",
        'ў' to "o", 'қ' to "q", 'ғ' to "g", 'ҳ' to "h"
    )

    fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            val mapped = cyr[ch]
            when {
                mapped != null -> sb.append(mapped)
                ch.isLetterOrDigit() -> sb.append(ch)
                ch == '\'' || ch == '’' || ch == 'ʻ' || ch == 'ʼ' || ch == '‘' || ch == '`' -> {}
                else -> sb.append(' ')
            }
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }
}

/** Sozlamalar (Gemini kaliti, til). */
object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("robo", Context.MODE_PRIVATE)
    fun geminiKey(ctx: Context): String = p(ctx).getString("gemini", "") ?: ""
    fun setGeminiKey(ctx: Context, v: String) = p(ctx).edit().putString("gemini", v.trim()).apply()
    fun lang(ctx: Context): String = p(ctx).getString("lang", "uz-UZ") ?: "uz-UZ"
    fun setLang(ctx: Context, v: String) = p(ctx).edit().putString("lang", v).apply()
}

/** Oxirgi eshitilgan/aytilgan gap (asosiy ekranda ko'rsatish uchun). */
object Status {
    @Volatile var last: String = "To'xtab turibdi"
    @Volatile var listener: ((String) -> Unit)? = null
    fun set(s: String) {
        last = s
        Handler(Looper.getMainLooper()).post { listener?.invoke(s) }
    }
}
