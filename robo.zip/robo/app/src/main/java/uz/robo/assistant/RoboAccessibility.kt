package uz.robo.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Telegram/WhatsApp ichida kontaktni tanlab, "Yuborish" tugmasini bosish uchun kutilayotgan vazifa. */
object AutoSend {
    class Req(val pkgs: Set<String>, val contact: String?, val deadline: Long) {
        var stage = if (contact == null) 1 else 0
    }

    @Volatile var current: Req? = null
    @Volatile var serviceEnabled = false

    fun arm(pkg: String, contact: String?) {
        val pkgs = if (pkg == "com.whatsapp") setOf(pkg)
        else setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.telegram.plus")
        current = Req(pkgs, contact, System.currentTimeMillis() + 20_000)
    }
}

class RoboAccessibility : AccessibilityService() {

    private val sendLabels = listOf("send", "yuborish", "jonatish", "отправить", "юбориш")

    override fun onServiceConnected() {
        AutoSend.serviceEnabled = true
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        AutoSend.serviceEnabled = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val req = AutoSend.current ?: return
        if (System.currentTimeMillis() > req.deadline) {
            AutoSend.current = null
            return
        }
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in req.pkgs) return
        val root = rootInActiveWindow ?: return

        if (req.stage == 0 && req.contact != null) {
            val node = root.findAccessibilityNodeInfosByText(req.contact)
                ?.firstOrNull { !it.isEditable }
            if (node != null && clickUp(node)) {
                req.stage = 1
            }
            return
        }

        val send = findSend(root)
        if (send != null && clickUp(send)) {
            AutoSend.current = null
        }
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (label in sendLabels) {
            val nodes = root.findAccessibilityNodeInfosByText(label) ?: continue
            val exact = nodes.firstOrNull {
                val t = it.text?.toString()?.trim()?.lowercase()
                val d = it.contentDescription?.toString()?.trim()?.lowercase()
                t == label || d == label
            }
            if (exact != null) return exact
        }
        return null
    }

    private fun clickUp(start: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = start
        while (n != null) {
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }
}
