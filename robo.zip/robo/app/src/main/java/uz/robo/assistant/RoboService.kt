package uz.robo.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Doim yoniq turuvchi xizmat: "Robo" so'zini kutadi, "Labbay" deydi, buyruqni bajaradi. */
class RoboService : Service() {

    companion object {
        const val CHANNEL = "robo"
        const val ACTION_STOP = "uz.robo.assistant.STOP"
        @Volatile var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var speaking = false
    private var awaitUntil = 0L
    private val wake = setOf("robo", "robot", "rabo", "robu", "ropo")

    private val restartRunnable = Runnable { startListening() }
    private val speakGuard = Runnable {
        if (speaking) {
            speaking = false
            startListening()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (!running) {
            running = true
            Status.set("Robo ishga tushdi. \"Robo\" deng")
            tts = TextToSpeech(this) { st ->
                main.post {
                    if (st == TextToSpeech.SUCCESS) {
                        setupVoice()
                        ttsReady = true
                    }
                    startListening()
                }
            }
        }
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Robo", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, RoboService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Robo eshityapti")
            .setContentText("\"Robo\" deb chaqiring")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "To'xtatish", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun setupVoice() {
        val t = tts ?: return
        // Lotin o'zbekchani eng yaxshi o'qiydigan tilni tanlaymiz: uz -> tr -> ru -> standart
        val options = listOf(Locale("uz", "UZ"), Locale("tr", "TR"), Locale("ru", "RU"), Locale.getDefault())
        for (l in options) {
            if (t.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE) {
                t.setLanguage(l)
                break
            }
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { afterSpeak() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { afterSpeak() }
        })
    }

    private fun afterSpeak() {
        main.post {
            main.removeCallbacks(speakGuard)
            speaking = false
            restart(250)
        }
    }

    // ---------- Eshitish ----------

    private fun restart(delayMs: Long) {
        main.removeCallbacks(restartRunnable)
        main.postDelayed(restartRunnable, delayMs)
    }

    private fun startListening() {
        if (!running || speaking) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Status.set("Mikrofon ruxsati yo'q")
            stopSelf()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Status.set("Telefonda ovoz tanish xizmati yo'q (Google ilovasini yangilang)")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang(this@RoboService))
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            recognizer?.startListening(i)
        } catch (e: Exception) {
            resetRecognizer()
            restart(1500)
        }
    }

    private fun resetRecognizer() {
        recognizer?.destroy()
        recognizer = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (speaking) return
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    Status.set("Mikrofon ruxsati yo'q")
                    stopSelf()
                }
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(150)
                else -> {
                    resetRecognizer()
                    restart(1500)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
            onHeard(list)
        }
    }

    // ---------- Tushunish va bajarish ----------

    private fun onHeard(list: List<String>) {
        val now = System.currentTimeMillis()
        for (heard in list) {
            val toks = heard.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            val wi = toks.indexOfFirst { Text.norm(it) in wake }
            if (wi >= 0) {
                val cmd = toks.drop(wi + 1).joinToString(" ")
                Status.set("Eshitdim: $heard")
                if (cmd.isBlank()) {
                    awaitUntil = now + 10_000
                    speak("Labbay")
                } else {
                    runCommand(cmd)
                }
                return
            }
        }
        if (now < awaitUntil && list.isNotEmpty()) {
            awaitUntil = 0
            Status.set("Eshitdim: ${list[0]}")
            runCommand(list[0])
            return
        }
        restart(100)
    }

    private fun runCommand(cmd: String) {
        Commands.handle(applicationContext, cmd) { reply ->
            main.post {
                // Robo savol bersa, "Robo" demasdan javob berish mumkin
                if (reply.trimEnd().endsWith("?")) awaitUntil = System.currentTimeMillis() + 12_000
                speak(reply)
            }
        }
    }

    private fun speak(text: String) {
        Status.set("Robo: $text")
        val t = tts
        if (!ttsReady || t == null) {
            restart(300)
            return
        }
        speaking = true
        main.removeCallbacks(restartRunnable)
        recognizer?.cancel()
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "robo")
        main.removeCallbacks(speakGuard)
        main.postDelayed(speakGuard, 15_000)
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        resetRecognizer()
        tts?.stop()
        tts?.shutdown()
        tts = null
        Status.set("To'xtab turibdi")
        super.onDestroy()
    }
}
