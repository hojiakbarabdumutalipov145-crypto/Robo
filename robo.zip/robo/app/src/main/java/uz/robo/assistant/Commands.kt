package uz.robo.assistant

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import java.util.Calendar

/** Aytilgan gapni buyruqqa aylantiradi va bajaradi. Javob matni reply() orqali qaytadi. */
object Commands {

    private val months = arrayOf(
        "yanvar", "fevral", "mart", "aprel", "may", "iyun",
        "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"
    )
    private val weekdays = arrayOf(
        "yakshanba", "dushanba", "seshanba", "chorshanba", "payshanba", "juma", "shanba"
    )

    private val callWords = setOf(
        "qongiroq", "kongiroq", "qongirok", "kongirok", "call", "zvonok", "chaqir", "chaqiring"
    )
    private val writeWords = setOf(
        "yoz", "yozing", "yozib", "yubor", "yuboring", "jonat", "jonating", "write", "send"
    )
    private val openWords = setOf(
        "och", "ochib", "ochish", "ochgin", "oching", "ishga", "tushir", "tushiring",
        "ilova", "ilovasi", "ilovani", "ilovasini", "open", "ber"
    )
    private val callNoise = setOf("qil", "qiling", "qilgin", "qilib", "qilish", "ga", "ka", "qa", "ni")

    private val aliases: Map<String, List<String>> = mapOf(
        "kamera" to listOf("kamera", "camera"),
        "sozlamalar" to listOf("settings", "sozlamalar"),
        "sozlama" to listOf("settings", "sozlamalar"),
        "galereya" to listOf("gallery", "galereya", "photos", "rasmlar"),
        "rasmlar" to listOf("gallery", "galereya", "photos", "rasmlar"),
        "xarita" to listOf("maps", "xarita"),
        "karta" to listOf("maps", "xarita"),
        "telefon" to listOf("phone", "telefon", "dialer"),
        "kontaktlar" to listOf("contacts", "kontaktlar"),
        "xabarlar" to listOf("messages", "xabarlar"),
        "brauzer" to listOf("chrome", "browser", "internet"),
        "xrom" to listOf("chrome"),
        "krom" to listOf("chrome"),
        "gugl" to listOf("google"),
        "kalkulyator" to listOf("calculator", "kalkulyator"),
        "yutub" to listOf("youtube"),
        "yutube" to listOf("youtube"),
        "vatsap" to listOf("whatsapp"),
        "watsap" to listOf("whatsapp"),
        "tg" to listOf("telegram"),
        "instagramm" to listOf("instagram"),
        "taymer" to listOf("clock", "soat")
    )

    private const val NO_OVERLAY =
        "Ilovalarni ochish uchun Robo ilovasida «Boshqa ilovalar ustida ko'rsatish» ruxsatini yoqing"

    /** Kalit bor bo'lsa Gemini hal qiladi, bo'lmasa yoki internet yo'q bo'lsa oddiy buyruqlar ishlaydi. */
    fun handle(ctx: Context, raw: String, reply: (String) -> Unit) {
        val key = Prefs.geminiKey(ctx)
        if (key.isBlank()) {
            handleRules(ctx, raw, reply)
            return
        }
        Thread {
            val r = try { Agent.run(ctx, key, raw) } catch (e: Exception) { null }
            if (r != null) reply(r) else handleRules(ctx, raw, reply)
        }.start()
    }

    private fun handleRules(ctx: Context, raw: String, reply: (String) -> Unit) {
        val tokens = raw.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val norms = tokens.map { Text.norm(it) }
        val canLaunch = Settings.canDrawOverlays(ctx)
        val needOverlay = "Ilovalarni ochish uchun Robo ilovasida «Boshqa ilovalar ustida ko'rsatish» ruxsatini yoqing"

        fun has(vararg w: String) = norms.any { it in w }

        if (norms.isEmpty()) {
            reply("Eshitaman")
            return
        }

        // 1) Oddiy gaplar
        if (norms.size <= 3) {
            if (has("rahmat", "raxmat")) { reply("Arzimaydi"); return }
            if (has("salom", "assalomu", "assalom")) { reply("Salom! Eshitaman"); return }
        }

        // 2) Vaqt va sana
        if (has("soat", "vaqt") && has("necha", "qancha", "nechi", "boldi")) {
            val c = Calendar.getInstance()
            reply("Soat %02d:%02d".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)))
            return
        }
        if (has("sana", "bugun", "kun") && has("necha", "qaysi", "nechanchi")) {
            val c = Calendar.getInstance()
            reply("Bugun ${c.get(Calendar.DAY_OF_MONTH)}-${months[c.get(Calendar.MONTH)]}, ${weekdays[c.get(Calendar.DAY_OF_WEEK) - 1]}")
            return
        }

        // 3) Chiroq (fonar)
        if (has("chiroq", "fonar", "fanar", "flash")) {
            val off = norms.any { it.startsWith("ochir") }
            val on = has("yoq", "yoqing", "yoqib", "och", "oching")
            if (off || on) {
                reply(setTorch(ctx, !off))
                return
            }
        }

        // 4) Taymer
        if (has("taymer", "timer")) {
            val n = norms.firstNotNullOfOrNull { it.toIntOrNull() }
            if (n != null) {
                val seconds = when {
                    has("soniya", "sekund") -> n
                    has("soat") -> n * 3600
                    else -> n * 60
                }
                if (!canLaunch) { reply(needOverlay); return }
                try {
                    val i = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                        putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                        putExtra(AlarmClock.EXTRA_MESSAGE, "Robo")
                        putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    ctx.startActivity(i)
                    reply("Taymer qo'yildi")
                } catch (e: Exception) {
                    reply("Taymer qo'ya olmadim")
                }
                return
            }
        }

        // 5) Xabar yozish (Telegram / WhatsApp / SMS)
        if (norms.any { it in writeWords }) {
            val dn = dativeName(norms)
            if (dn != null) {
                sendMessage(ctx, tokens, norms, dn, canLaunch, needOverlay, reply)
                return
            }
        }

        // 6) Qo'ng'iroq
        if (norms.any { it in callWords }) {
            callCommand(ctx, raw, norms, reply)
            return
        }

        // 7) Musiqa / video qo'yish
        if (has("musiqa", "qoshiq", "klip", "video") && has("qoy", "qoying", "ijro", "eshit", "chal", "chalib", "top")) {
            val skip = setOf("musiqa", "qoshiq", "klip", "video", "qoy", "qoying", "ijro", "eshit", "chal", "chalib", "top", "ni", "bir", "youtube", "yutub", "dan", "da")
            val q = tokens.filterIndexed { i, _ -> norms[i] !in skip && norms[i].isNotEmpty() }.joinToString(" ")
            if (!canLaunch) { reply(needOverlay); return }
            val url = if (q.isBlank()) "https://www.youtube.com"
            else "https://www.youtube.com/results?search_query=" + Uri.encode(q)
            reply(launchView(ctx, url, if (q.isBlank()) "YouTube ochildi" else "$q qidirilyapti"))
            return
        }

        // 8) Internetdan qidirish
        val searchIdx = norms.indexOfFirst { it in setOf("qidir", "qidirib", "qidiring", "izla", "izlab", "google") }
        if (searchIdx >= 0 && searchIdx < norms.size - 1) {
            val q = tokens.drop(searchIdx + 1).joinToString(" ")
            if (!canLaunch) { reply(needOverlay); return }
            try {
                val i = Intent(Intent.ACTION_WEB_SEARCH).apply {
                    putExtra(SearchManager.QUERY, q)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(i)
                reply("$q qidirilyapti")
            } catch (e: Exception) {
                reply(launchView(ctx, "https://www.google.com/search?q=" + Uri.encode(q), "$q qidirilyapti"))
            }
            return
        }

        // 9) Ilova ochish
        if (norms.any { it in openWords }) {
            val q = norms.filter { it.isNotEmpty() && it !in openWords }
            if (q.isEmpty()) { reply("Qaysi ilovani ochay?"); return }
            if (!canLaunch) { reply(needOverlay); return }
            reply(openApp(ctx, q))
            return
        }

        reply("Buni tushunmadim")
    }

    // ---------- Xabar yuborish ----------

    private class Dative(val nameEnd: Int, val name: String)

    /** "Aliga" yoki "Ali ga" shaklidagi ism va uning oxirgi token indeksini topadi. */
    private fun dativeName(norms: List<String>): Dative? {
        for (i in norms.indices) {
            val t = norms[i]
            if (isAppWord(t) || t in writeWords) continue
            if (t == "ga" || t == "ka" || t == "qa") {
                if (i > 0 && norms[i - 1].isNotEmpty()) return Dative(i, norms[i - 1])
                continue
            }
            if (t.length > 3 && (t.endsWith("ga") || t.endsWith("ka") || t.endsWith("qa"))) {
                return Dative(i, t.dropLast(2))
            }
        }
        return null
    }

    private fun isTelegram(t: String) = t.startsWith("telegram") || t == "tg"
    private fun isWhatsApp(t: String) = t.startsWith("whatsapp") || t.startsWith("watsap") || t.startsWith("vatsap")
    private fun isSms(t: String) = t.startsWith("sms") || t.startsWith("esemes")
    private fun isAppWord(t: String) = isTelegram(t) || isWhatsApp(t) || isSms(t) || t == "xabar" || t == "xabarni"

    private fun sendMessage(
        ctx: Context, tokens: List<String>, norms: List<String>, dn: Dative,
        canLaunch: Boolean, needOverlay: String, reply: (String) -> Unit
    ) {
        val verbIdx = norms.indexOfFirst { it in writeWords }
        val debIdx = norms.indexOf("deb")
        fun skip(j: Int) = norms[j].isEmpty() || isAppWord(norms[j]) || norms[j] in writeWords
        fun join(r: IntRange) = r.filterNot { skip(it) }.joinToString(" ") { tokens[it] }

        var msg = when {
            debIdx > dn.nameEnd -> join((dn.nameEnd + 1) until debIdx)
            debIdx in 0 until dn.nameEnd -> join(0 until debIdx)
            else -> join((maxOf(verbIdx, dn.nameEnd) + 1) until tokens.size)
        }
        if (msg.isBlank() && verbIdx > dn.nameEnd) msg = join((dn.nameEnd + 1) until verbIdx)
        if (msg.isBlank()) { reply("Nima deb yozay?"); return }

        val app = when {
            norms.any { isWhatsApp(it) } -> "wa"
            norms.any { isSms(it) } -> "sms"
            else -> "tg"
        }
        deliver(ctx, app, dn.name, msg, canLaunch, needOverlay, reply)
    }

    private fun deliver(
        ctx: Context, app: String, person: String, msg: String,
        canLaunch: Boolean, needOverlay: String, reply: (String) -> Unit
    ) {
        when (app) {
            "tg" -> {
                if (!canLaunch) { reply(needOverlay); return }
                sendTelegram(ctx, person, msg, reply)
            }
            "wa" -> {
                val c = findContact(ctx, person)
                if (c == null) { reply("$person kontaktlarda topilmadi"); return }
                if (!canLaunch) { reply(needOverlay); return }
                var digits = c.second.filter { it.isDigit() }
                if (digits.length == 9) digits = "998$digits" // O'zbekiston raqami kod'siz saqlangan bo'lsa
                AutoSend.arm("com.whatsapp", null)
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=" + Uri.encode(msg))).apply {
                    setPackage("com.whatsapp")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    ctx.startActivity(i)
                    reply(if (AutoSend.serviceEnabled) "${c.first}ga yuboryapman" else "WhatsApp ochildi, yuborish tugmasini bosing")
                } catch (e: Exception) {
                    reply("WhatsApp'ni ocholmadim")
                }
            }
            else -> {
                if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    reply("SMS yuborish ruxsati yo'q"); return
                }
                val c = findContact(ctx, person)
                if (c == null) { reply("$person kontaktlarda topilmadi"); return }
                try {
                    val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
                    else @Suppress("DEPRECATION") SmsManager.getDefault()
                    sm.sendMultipartTextMessage(c.second, null, sm.divideMessage(msg), null, null)
                    reply("${c.first}ga SMS yuborildi")
                } catch (e: Exception) {
                    reply("SMS yuborib bo'lmadi")
                }
            }
        }
    }

    private fun sendTelegram(ctx: Context, name: String, msg: String, reply: (String) -> Unit) {
        val pkg = listOf("org.telegram.messenger", "org.telegram.messenger.web", "org.telegram.plus")
            .firstOrNull { isInstalled(ctx, it) }
        if (pkg == null) { reply("Telegram o'rnatilmagan"); return }
        AutoSend.arm(pkg, name)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, msg)
            setPackage(pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            ctx.startActivity(i)
            reply(if (AutoSend.serviceEnabled) "$name ga yuboryapman" else "Telegram ochildi, kimga yuborishni o'zingiz tanlang")
        } catch (e: Exception) {
            reply("Telegram'ni ocholmadim")
        }
    }

    private fun isInstalled(ctx: Context, pkg: String): Boolean =
        try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }

    // ---------- Qo'ng'iroq ----------

    private fun callCommand(ctx: Context, raw: String, norms: List<String>, reply: (String) -> Unit) {
        val digits = raw.filter { it.isDigit() || it == '+' }
        val number: String
        val who: String
        if (digits.count { it.isDigit() } >= 7) {
            number = digits
            who = digits
        } else {
            val dn = dativeName(norms)
            val q = dn?.name
                ?: norms.filter { it.isNotEmpty() && it !in callWords && it !in callNoise }.joinToString(" ")
            if (q.isBlank()) { reply("Kimga qo'ng'iroq qilay?"); return }
            if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                reply("Kontaktlarga ruxsat yo'q"); return
            }
            val c = findContact(ctx, q)
            if (c == null) { reply("$q kontaktlarda topilmadi"); return }
            number = c.second.filter { it.isDigit() || it == '+' }
            who = c.first
        }
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            reply("Qo'ng'iroq qilish ruxsati yo'q"); return
        }
        try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.placeCall(Uri.fromParts("tel", number, null), Bundle())
            reply("$who ga qo'ng'iroq qilyapman")
        } catch (e: Exception) {
            reply("Qo'ng'iroq qila olmadim")
        }
    }

    private fun findContact(ctx: Context, query: String): Pair<String, String>? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val q = Text.norm(query)
        if (q.isEmpty()) return null
        var best: Pair<String, String>? = null
        var bestScore = 0
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val n = Text.norm(name)
                val score = when {
                    n == q -> 4
                    n.startsWith(q) -> 3
                    n.split(" ").any { it.startsWith(q) } -> 2
                    n.contains(q) -> 1
                    n.length >= 3 && q.contains(n) -> 1
                    else -> 0
                }
                if (score > bestScore) {
                    bestScore = score
                    best = name to number
                }
            }
        }
        return best
    }

    // ---------- Ilova ochish ----------

    private fun openApp(ctx: Context, query: List<String>): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val candidates = query.flatMap { aliases[it] ?: listOf(it) }
        var bestPkg: String? = null
        var bestLabel = ""
        var best = 0
        for (ri in pm.queryIntentActivities(main, 0)) {
            val shown = ri.loadLabel(pm).toString()
            val lbl = Text.norm(shown)
            if (lbl.isEmpty()) continue
            for (t in candidates) {
                val s = when {
                    lbl == t -> 100
                    lbl.length >= 3 && t.startsWith(lbl) -> 90
                    t.length >= 3 && lbl.startsWith(t) -> 70
                    t.length >= 4 && lbl.contains(t) -> 50
                    else -> 0
                }
                if (s > best) {
                    best = s
                    bestPkg = ri.activityInfo.packageName
                    bestLabel = shown
                }
            }
        }
        val pkg = bestPkg ?: return "${query.joinToString(" ")} ilovasini topolmadim"
        val li = pm.getLaunchIntentForPackage(pkg) ?: return "$bestLabel ni ocholmadim"
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(li)
            "$bestLabel ochilyapti"
        } catch (e: Exception) {
            "$bestLabel ni ocholmadim"
        }
    }

    private fun launchView(ctx: Context, url: String, ok: String): String =
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ok
        } catch (e: Exception) {
            "Ocholmadim"
        }

    // ---------- Gemini (Agent) uchun amallar: natijani matn qilib qaytaradi ----------

    fun actCall(ctx: Context, target: String): String {
        val digits = target.filter { it.isDigit() || it == '+' }
        val number: String
        val who: String
        if (digits.count { it.isDigit() } >= 7) {
            number = digits
            who = digits
        } else {
            if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                return "Kontaktlarga ruxsat yo'q"
            }
            val c = findContact(ctx, target) ?: return "$target kontaktlarda topilmadi"
            number = c.second.filter { it.isDigit() || it == '+' }
            who = c.first
        }
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return "Qo'ng'iroq qilish ruxsati yo'q"
        }
        return try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.placeCall(Uri.fromParts("tel", number, null), Bundle())
            "$who ga qo'ng'iroq qilinyapti"
        } catch (e: Exception) {
            "Qo'ng'iroq qila olmadim"
        }
    }

    fun actMessage(ctx: Context, app: String, contact: String, text: String): String {
        if (contact.isBlank()) return "Kimga yozay?"
        if (text.isBlank()) return "Nima deb yozay?"
        val a = when (app.lowercase()) {
            "whatsapp" -> "wa"
            "sms" -> "sms"
            else -> "tg"
        }
        var out = ""
        deliver(ctx, a, contact, text, Settings.canDrawOverlays(ctx), NO_OVERLAY) { out = it }
        return out.ifBlank { "Bajarildi" }
    }

    fun actSearchContacts(ctx: Context, query: String): String {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return "Kontaktlarga ruxsat yo'q"
        }
        val q = Text.norm(query)
        if (q.isEmpty()) return "So'rov bo'sh"
        val found = LinkedHashMap<String, Int>()
        val cols = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val n = Text.norm(name)
                val score = when {
                    n == q -> 4
                    n.startsWith(q) -> 3
                    n.split(" ").any { it.startsWith(q) } -> 2
                    n.contains(q) -> 1
                    else -> 0
                }
                if (score > 0) found[name] = maxOf(found[name] ?: 0, score)
            }
        }
        if (found.isEmpty()) return "Mos kontakt topilmadi"
        return found.entries.sortedByDescending { it.value }.take(5).joinToString(", ") { it.key }
    }

    fun actOpenApp(ctx: Context, name: String): String {
        if (!Settings.canDrawOverlays(ctx)) return NO_OVERLAY
        val q = Text.norm(name).split(" ").filter { it.isNotEmpty() }
        if (q.isEmpty()) return "Qaysi ilova?"
        return openApp(ctx, q)
    }

    fun actTimer(ctx: Context, seconds: Int): String {
        if (seconds <= 0) return "Vaqt noto'g'ri"
        if (!Settings.canDrawOverlays(ctx)) return NO_OVERLAY
        return try {
            val i = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, "Robo")
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(i)
            "Taymer qo'yildi"
        } catch (e: Exception) {
            "Taymer qo'ya olmadim"
        }
    }

    fun actTorch(ctx: Context, on: Boolean): String = setTorch(ctx, on)

    fun actSearch(ctx: Context, query: String): String {
        if (query.isBlank()) return "Nimani qidiray?"
        if (!Settings.canDrawOverlays(ctx)) return NO_OVERLAY
        return launchView(ctx, "https://www.google.com/search?q=" + Uri.encode(query), "Qidirilyapti")
    }

    fun actMusic(ctx: Context, query: String): String {
        if (!Settings.canDrawOverlays(ctx)) return NO_OVERLAY
        val url = if (query.isBlank()) "https://www.youtube.com"
        else "https://www.youtube.com/results?search_query=" + Uri.encode(query)
        return launchView(ctx, url, "YouTube ochildi")
    }

    // ---------- Chiroq ----------

    private fun setTorch(ctx: Context, on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Chiroq topilmadi"
            cm.setTorchMode(id, on)
            if (on) "Chiroq yoqildi" else "Chiroq o'chirildi"
        } catch (e: Exception) {
            "Chiroqni boshqara olmadim"
        }
    }
}
