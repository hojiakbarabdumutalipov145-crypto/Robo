package uz.robo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Gemini "miya": gapni tushunadi, kerakli amallarni (asboblarni) chaqiradi va qisqa javob beradi. */
object Agent {
    private const val URL_STR =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent"

    private val history = ArrayList<JSONObject>()
    private var lastUse = 0L

    private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)
    private fun int(desc: String) = JSONObject().put("type", "integer").put("description", desc)
    private fun bool(desc: String) = JSONObject().put("type", "boolean").put("description", desc)

    private fun fn(name: String, desc: String, props: Map<String, JSONObject>, required: List<String>): JSONObject {
        val p = JSONObject()
        for ((k, v) in props) p.put(k, v)
        return JSONObject().put("name", name).put("description", desc).put(
            "parameters",
            JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(required))
        )
    }

    private val tools: JSONArray = JSONArray().put(
        JSONObject().put(
            "functionDeclarations",
            JSONArray()
                .put(fn("call_contact", "Kontaktga yoki raqamga telefon qo'ng'irog'i qiladi.",
                    mapOf("target" to str("Kontakt ismi yoki telefon raqami")), listOf("target")))
                .put(fn("send_message", "Odamga xabar yuboradi (Telegram, WhatsApp yoki SMS).",
                    mapOf(
                        "app" to JSONObject().put("type", "string").put("description", "Qaysi ilova")
                            .put("enum", JSONArray(listOf("telegram", "whatsapp", "sms"))),
                        "contact" to str("Kontakt ismi"),
                        "text" to str("Yuboriladigan xabar matni")
                    ), listOf("app", "contact", "text")))
                .put(fn("search_contacts", "Kontaktlardan ism bo'yicha qidiradi. 'akam', 'dadam' kabi nomlar uchun ishlating.",
                    mapOf("query" to str("Qidiriladigan ism")), listOf("query")))
                .put(fn("open_app", "Telefondagi ilovani ochadi.",
                    mapOf("name" to str("Ilova nomi")), listOf("name")))
                .put(fn("set_timer", "Taymer qo'yadi.",
                    mapOf("seconds" to int("Soniyalarda davomiyligi")), listOf("seconds")))
                .put(fn("set_reminder", "Eslatma qo'yadi: vaqti kelganda telefon ovoz bilan eslatadi. delay_minutes yoki time_hhmm dan bittasini bering.",
                    mapOf(
                        "text" to str("Nimani eslatish kerak"),
                        "delay_minutes" to int("Necha daqiqadan keyin"),
                        "time_hhmm" to str("Aniq vaqt, 24 soatlik HH:mm, masalan 18:30")
                    ), listOf("text")))
                .put(fn("flashlight", "Telefon chiroqini (fonar) yoqadi yoki o'chiradi.",
                    mapOf("on" to bool("true yoqish, false o'chirish")), listOf("on")))
                .put(fn("web_search", "Google'da qidiradi.",
                    mapOf("query" to str("Qidiruv so'rovi")), listOf("query")))
                .put(fn("play_music", "YouTube'da musiqa yoki video qidirib ochadi.",
                    mapOf("query" to str("Nima qo'yish kerak")), listOf("query")))
        )
    )

    private fun system(): String {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm, EEEE", Locale.US).format(Date())
        return "Sen Robo ismli ovozli yordamchisan, foydalanuvchining telefonida ishlaysan. " +
            "O'zbek tilida (lotin harflarida), juda qisqa (1-2 jumla), oddiy so'zlar bilan gapir. Ro'yxat va markdown ishlatma. " +
            "Foydalanuvchi gapi ovozdan matnga o'girilgan, shuning uchun xatolar bo'lishi mumkin; ma'noni taxmin qil. " +
            "Biror ish so'ralsa, gapirib o'tirmasdan mos asbobni chaqir, so'ng natijani qisqa ayt. " +
            "Kontakt noaniq bo'lsa ('akam', 'dadam') avval search_contacts bilan qidir. Bir nechta mos kelsa yoki xabar matni noaniq bo'lsa, " +
            "qisqa savol ber va savol belgisi bilan tugat. Asbob xato qaytarsa, buni foydalanuvchiga aniq ayt, bajarildi dema. " +
            "Hozirgi vaqt: $now."
    }

    @Synchronized
    fun run(ctx: Context, key: String, text: String): String? {
        val now = System.currentTimeMillis()
        if (now - lastUse > 5 * 60_000) history.clear()
        lastUse = now
        val start = history.size
        history.add(
            JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text)))
        )
        var steps = 0
        while (steps < 6) {
            steps++
            val content = call(key)
            if (content == null) {
                while (history.size > start) history.removeAt(history.size - 1)
                return null
            }
            history.add(content)
            val parts = content.optJSONArray("parts") ?: JSONArray()
            val responses = JSONArray()
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                val fc = p.optJSONObject("functionCall")
                if (fc != null) {
                    val name = fc.optString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    val result = try { exec(ctx, name, args) } catch (e: Exception) { "Xato: ${e.message}" }
                    responses.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", name).put("response", JSONObject().put("result", result))
                        )
                    )
                } else if (p.has("text") && !p.optBoolean("thought", false)) {
                    sb.append(p.optString("text"))
                }
            }
            if (responses.length() == 0) {
                trim()
                return sb.toString().trim().ifBlank { "Bajarildi" }
            }
            history.add(JSONObject().put("role", "user").put("parts", responses))
        }
        trim()
        return "Bajarildi"
    }

    private fun trim() {
        while (history.size > 24) history.removeAt(0)
        // Tarix model javobidan emas, foydalanuvchi gapidan boshlansin
        while (history.isNotEmpty() && !isPlainUser(history[0])) history.removeAt(0)
    }

    private fun isPlainUser(c: JSONObject): Boolean {
        if (c.optString("role") != "user") return false
        val p = c.optJSONArray("parts") ?: return false
        return p.length() > 0 && p.getJSONObject(0).has("text")
    }

    private fun exec(ctx: Context, name: String, a: JSONObject): String = when (name) {
        "call_contact" -> Commands.actCall(ctx, a.optString("target"))
        "send_message" -> Commands.actMessage(ctx, a.optString("app", "telegram"), a.optString("contact"), a.optString("text"))
        "search_contacts" -> Commands.actSearchContacts(ctx, a.optString("query"))
        "open_app" -> Commands.actOpenApp(ctx, a.optString("name"))
        "set_timer" -> Commands.actTimer(ctx, a.optInt("seconds"))
        "set_reminder" -> Reminders.schedule(
            ctx, a.optString("text"),
            if (a.has("delay_minutes")) a.optInt("delay_minutes") else null,
            a.optString("time_hhmm", "")
        )
        "flashlight" -> Commands.actTorch(ctx, a.optBoolean("on", true))
        "web_search" -> Commands.actSearch(ctx, a.optString("query"))
        "play_music" -> Commands.actMusic(ctx, a.optString("query"))
        else -> "Bunday amal yo'q: $name"
    }

    /** Gemini'ga so'rov yuboradi va model javobining "content" qismini qaytaradi (xato bo'lsa null). */
    private fun call(key: String): JSONObject? {
        return try {
            val c = URL(URL_STR).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
                .put("tools", tools)
                .put("contents", JSONArray(history))
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val ok = c.responseCode in 200..299
            val text = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
            if (!ok) {
                Status.set("Gemini xatosi: ${c.responseCode}")
                return null
            }
            JSONObject(text).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
        } catch (e: Exception) {
            null
        }
    }
}
